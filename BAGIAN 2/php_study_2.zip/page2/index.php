<?php
// Definisikan class Menu
class Menu {

}

// Tetapkan instance baru dari kelas Menu ke variable $curry
$curry = new Menu();

// Tetapkan instance baru dari kelas Menu ke variable $pasta
$pasta = new Menu()

?>