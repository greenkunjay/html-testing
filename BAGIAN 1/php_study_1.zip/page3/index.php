<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <!-- Deklarasikan variable $fruit dibawah -->
  <?php
    $fruit = 'Apel';
    echo $fruit;
    
  ?>

  <br>

  <!-- Deklarasikan variable $sum dibawah -->
  <?php
    $sum = 8 + 9;
    echo $sum;
    
  ?>

</body>
</html>
