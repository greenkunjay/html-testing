<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    // echo 'Hello, world!'
    echo 'Hello, world!';
  ?>
  
  <br>

  <?php
    // echo 7 * 2
    echo 7 * 2;
  ?>

  <br>

  <?php
    // echo 8 % 3
    echo 8 % 3;
  ?>

</body>
</html>