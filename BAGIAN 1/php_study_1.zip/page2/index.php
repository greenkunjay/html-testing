<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <!-- Cetak 5 + 7 dibawah -->
  <?php
   echo 5 + 7;
  ?>

  <br>

  <!-- Cetak '5 + 7' dibawah -->
  <?php
    echo '5 + 7';
  ?>

</body>
</html>