<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    // Buat array dibawah
    $colors = ['Merah', 'Biru', 'Kuning'];
    echo $colors[0];
    $colors[] = 'Putih';
    echo $colors[3];
    
  ?>

</body>
</html>