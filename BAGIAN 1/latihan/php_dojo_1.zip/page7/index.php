<?php
$prices = array(10, 6, 7, 8);
echo 'Nilai $prices: ';
foreach ($prices as $price) {
  echo $price.' ';
}
echo '<br>';
echo '-----';
echo '<br>';

// Ketik code Anda dibawah
$price = array_sum($prices);
echo "Harga total adalah $" . $price . "<br>";
$price_max = max($prices);
echo "Harga termahal adalah $" . $price_max;

?>