<?php
$menus = array(
  array('name' => 'GULAI', 'price' => 9),
  array('name' => 'PASTA', 'price' => 12),
  array('name' => 'KOPI', 'price' => 6),
);
$totalPrice = 0;
$maxPrice = 0;
$maxPriceMenuName = '';
// Ketik code Anda dibawah
foreach ($menus as $menu) {
  $price = $menu["price"];
  $name = $menu["name"];
  echo $menu["name"] . " berharga " . "$" . $menu["price"] . "<br>";
  $totalPrice += $price;
  if ($price > $maxPrice) {
    // Perbarui $maxPrice dengan nilai tertinggi
    $maxPrice = $price;
    // Perbarui $maxPriceMenuName dengan nama item termahal yang baru
    $maxPriceMenuName = $name;
  }
}

echo "Harga total adalah $" . $totalPrice . "<br>";
echo 'Harga item termahal adalah'.$maxPriceMenuName.' dengan harga $'.$maxPrice;
?>