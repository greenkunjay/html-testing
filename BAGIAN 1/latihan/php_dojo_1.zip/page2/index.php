<?php
$name = 'Tom';
echo 'Nilai $name: '.$name;
echo '<br>';
echo '-----';
echo '<br>';

// Ketik code Anda dibawah
$name = "Nama saya adalah " . $name;
echo $name;
?>