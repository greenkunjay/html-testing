<?php
$menus = array(
  array('name' => 'GULAI', 'price' => 9),
  array('name' => 'PASTA', 'price' => 12),
  array('name' => 'KOPI', 'price' => 6)
);
$totalPrice = 0;
// Ketik code Anda dibawah
foreach ($menus as $menu) {
  $price = $menu["price"];
  echo $menu["name"] . " berharga " . "$" . $menu["price"] . "<br>";
  $totalPrice += $price;
}

echo "Harga total adalah $" . $totalPrice;
?>