<?php 
// Import file menu.php
require_once('menu.php');

// Buat class Drink yang diwariskan dari class Menu
class Drink extends Menu {
  
}

?>