<?php 
// Import file menu.php
require_once('menu.php');

// Buat class Food yang diwariskan dari class Menu
class Food extends Menu {
  
}

?>